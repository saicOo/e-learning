<?php

namespace App\Http\Controllers;

use App\Models\Student;
use Illuminate\Http\Request;
use App\Http\Controllers\BaseController as BaseController;

class StudentController extends BaseController
{

    

}

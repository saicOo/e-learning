<?php

namespace App\Http\Controllers\Dashboard;

use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Http\Response;
class AuthController extends Controller
{

    /**
     * @OA\Post(
     *     path="/api/dashboard/login",
     *      operationId="authLogin",
     *      tags={"Dashboard Api Auth User"},
     *     summary="Login User in Dashboard",
     * @OA\RequestBody(
     *         @OA\JsonContent(
     *             type="object",
     *              required={"email", "password"},
     *             @OA\Property(property="email", type="email", example="manger@app.com"),
     *             @OA\Property(property="password", type="string", example="1234"),
     *         ),
     *     ),
     *     @OA\Response(response=200, description="OK"),
     * )
     */
    public function login(Request $request){

        try {
            $validateUser = Validator::make($request->all(),
            [
                'email' => 'required|email|string|max:255',
                'password' => 'required'
            ]);

            if($validateUser->fails()){
                return response()->json([
                    'success' => false,
                    'status_code' => Response::HTTP_UNPROCESSABLE_ENTITY,
                    'message' => 'validation error',
                    'errors' => $validateUser->errors()
                ], 200);
            }

            $user = User::where('email', $request->email)->first();

            if (!$user || !Hash::check($request->password, $user->password)) {
                return response()->json([
                    'success' => false,
                    'status_code' => Response::HTTP_UNAUTHORIZED,
                    'message' => 'Email or password is incorrect!'
                ], 200);
            }

            $token = $user->createToken('token',['user'])->plainTextToken;

            // $cookie = cookie('token', $token, 60 * 24); // 1 day
            // $cookie = cookie('token', $token, 3)->withSameSite('None'); // 1 minute
            $cookie = cookie('token', $token, 3); // 1 minute

            return response()->json([
                'status' => true,
                'message' => 'User Logged In Successfully',
                'data' => [
                    'user' => $user,
                ]
                ],200)->withCookie($cookie);

        } catch (\Throwable $th) {
            return response()->json([
                'success' => false,
                'message' => $th->getMessage()
            ], 500);
        }
    }

    /**
     * @OA\Post(
     *     path="/api/dashboard/logout",
     *     tags={"Dashboard Api Auth User"},
     *     summary="Auth Logout",
     *     @OA\Response(response=200, description="OK"),
     *       @OA\Response(response=401, description="Unauthenticated"),
     * )
     */
    public function logout(Request $request)
    {
        $request->user()->currentAccessToken()->delete();

        $cookie = cookie()->forget('token');

        return response()->json([
            'message' => 'Logged out successfully!'
        ])->withCookie($cookie);
    }
}

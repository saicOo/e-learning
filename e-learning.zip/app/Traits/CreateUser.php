<?php
namespace App\Traits;

use App\Models\User;

trait CreateUser
{
    private function createUser($data){
        
    }
}
